function M = mass_matrix(m)

% Returns the mass matrix of the four-bar linkage
%
% m:        mass of each rod
%
% Authors: F. Gonz�lez, P. Masarati, and J. Cuadrado.
% Address all correspondence to f.gonzalez@udc.es

% Number of variables: 2*2 + 1 (x, y coordinates of points, and phi)
M = zeros(5,5);

% Contribution of rod P0-P1
M(2, 2) = 1.0/3.0;
M(3, 3) = 1.0/3.0;

% Contribution the other two rods
% Only upper half of matrix is filled here
    
% Horizontal rod, acting between points C and D
for k=0:3
    M(2+k, 2+k)     = M(2+k, 2+k) + 1.0/3.0;
end
M(2, 4) = M(2, 4)   + 1.0/6.0;
M(3, 5) = M(3, 5)   + 1.0/6.0;

% Vertical rod, acting between the ground and point D
for k=2:3
    M(2+k, 2+k)     = M(2+k, 2+k) + 1.0/3.0;
end

% Make mass matrix symmetric
for j=1:5
    for k=1:j-1
       M(j,k) = M(k,j);   
    end
end

% Scale times rod mass
M = m*M;
