function q = positionProb_qFromz(FOURBAR, zidx, q0, PARAMSposProb)

% Solve the position problem of the linkage starting from an initial quess,
% q0.
% The values of the degrees of freedom in q0 are not modified.
%
% FOURBAR:  system properties
% zidx:     index of independent coordinate in array q
% q0:       initial guess for q
% q:        generalized coordinates after the position problem is solved
%
% Authors: F. Gonz�lez, P. Masarati, and J. Cuadrado.
% Address all correspondence to f.gonzalez@udc.es

% Initialize q
q = q0;

for i=1:PARAMSposProb.maxIters
    
    % Obtain Jacobian matrix and constraints array
    [Phi, Jac, ~, ~, ~] = constr_terms(FOURBAR, q, zeros(length(q)));
    
    % Jac is not necessarily a square matrix. Instead of Jac * deltaq = Phi,
    % Jac'Jac * deltaq = Jac'Phi is solved to compute the increment of q
    ATA = Jac'*Jac;
    RHS = -Jac'*Phi;
    
    % Enforce that the d.o.f values remain unchanged
    ATA(zidx,zidx)  = PARAMSposProb.penalty;
    RHS(zidx)     	= 0.0;
    
    % Evaluate increment
    deltaq = ATA\RHS;
    
    % Increment q0
    q = q + deltaq;
    
	% Check violation of constraints
    if (norm(Phi,2) < PARAMSposProb.maxViolPhi); 
        break; 
    end
        
end

if PARAMSposProb.message == 1
    disp('Position problem finalized')
    str = ['Number of iterations: ' num2str(i)];
    disp(str)
    str = ['Violation of constraints: ' num2str(norm(Phi,2))];
    disp(str)
end