function [R, dRdq] = evalRMtx(FOURBAR, zidx, q)

% Evaluates the R (velocity transformation matrix) and its derivatives for
% a given set of dependent variables
%
% FOURBAR:  system properties
% zidx:     index of independent coordinate in array q
% q:        generalized coordinates
% R:        velocity transformation matrix
% dRdq:     Jacobian of the R matrix with respect to gen. coordinates q
%
% Authors: F. Gonz�lez, P. Masarati, and J. Cuadrado.
% Address all correspondence to f.gonzalez@udc.es

% R matrix
R = velocityProb_qFromz(FOURBAR, zidx, 1.0, q);

% Retrieve Jacobian and B matrix
[~, Jac, ~, dJacdq, B] = constr_terms(FOURBAR, q, zeros(length(q)));

% Partial derivative of R matrix w.r.t. dependent coordinates
TERM_1  = [Jac; B]^(-1);
TERM_2  = -hypergemv(dJacdq, R);
dRdq    = TERM_1 * [TERM_2; zeros(1, size(TERM_2,2))];
