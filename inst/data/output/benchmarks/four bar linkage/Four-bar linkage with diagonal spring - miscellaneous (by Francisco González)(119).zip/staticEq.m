function q_eq = staticEq(FOURBAR, zidx, q, PARAMSposProb, PARAMSstaticEq)

% Solve the static equilibrium problem for the four-bar linkage using 
% Newton-Raphson iteration
%
% FOURBAR:          system properties
% zidx:             index of independent coordinate in array q
% q:                initial value of the generalized coordinates
% PARAMSposProb:    parameters of the position problem solution method
% PARAMSstaticEq:   parameters of the static equilibrium problem solution method
% q_eq:             generalized coordinates in the equilibrium configuration
%
% Authors: F. Gonz�lez, P. Masarati, and J. Cuadrado.
% Address all correspondence to f.gonzalez@udc.es

for i=1:PARAMSstaticEq.maxIters
    
    % Solve position problem to ensure consistency
    q = positionProb_qFromz(FOURBAR, 1, q, PARAMSposProb);
    
    % Evaluate R matrix
    [R, dRdq] = evalRMtx(FOURBAR, zidx, q);
    
    % Evaluate array of forces and stiffness matrix
    [f, dfdq] = evalForces(FOURBAR, q);
    
	% Evaluate tangent matrix and residual
    Tangent     = R' * (dRdq*f + dfdq*R);
    Residual    = R'*f;
    
    % Evaluate increment
    Increment   = -Tangent\Residual;
    
    % Update positions
    q(1)    = q(1) + Increment;
    
    % Check if error is admissible
    if (abs(Increment) < PARAMSstaticEq.maxError); 
        break; 
    end
    
end

if PARAMSstaticEq.message == 1
    disp('Static equilibrium problem finalized')
    str = ['Number of iterations: ' num2str(i)];
    disp(str)
    str = ['Residual force: ' num2str(norm(R'*f,2))];
    disp(str)
    str = ['Residual increment: ' num2str(norm(Increment))];
    disp(str)
end

% Assign
q_eq = q;
