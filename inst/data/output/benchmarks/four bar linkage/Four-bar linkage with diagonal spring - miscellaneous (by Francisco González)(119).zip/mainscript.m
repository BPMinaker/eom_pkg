% Code for the linearization of the dynamics equations of a four-bar 
% linkage with diagonal spring.
% Modelled with 4 natural coordinates (x, y coordinates of points C, D) and
% the angle of rod B-D with respect to global x axis; and 3 kinematic
% constraints enforcing constant distance between the tips of the rods.
% The dynamics are formulated and linearized using the velocity 
% transformation described in [1].
%
% [1] F. Gonz�lez, P. Masarati, and J. Cuadrado. 
% On the linearization of multibody dynamics formulations. 
% Proc. of the ASME 2016 IDETC/CIE, paper 59277, Charlotte, NC, USA, 2016
%
% Authors: F. Gonz�lez, P. Masarati, and J. Cuadrado.
% Address all correspondence to f.gonzalez@udc.es

% ______________________________________________________________ Initialize
close all
clear all

% _______________________________________________________ System definition

% System properties
FOURBAR.m=1;                    % Mass of each rod [kg]
FOURBAR.L=1;                    % Rod length [m]
FOURBAR.g=9.81;                 % Gravity [m/s^2]
FOURBAR.k=25.0;                 % Spring stiffness [N/m]
FOURBAR.L0=FOURBAR.L*sqrt(2.0); % Natural length of spring [m]

%_______________________________________ Determination of equilibrium angle 

% Initial guess for the equilibrium configuration
phi_0_guess     = 2.23;  
q_0_guess       = get_q_from_phi(FOURBAR, phi_0_guess);

% Parameters for position problem
PARAMSposProb.penalty       = 1.0e15;           % Penalty factor
PARAMSposProb.maxIters      = 500;              % Max. number of iterations
PARAMSposProb.maxViolPhi    = 1.0e-15;          % Max. allowed violation of kinematic constraints
PARAMSposProb.message       = 0;                % Display message with results

% Parameters for static equilibrium problem
PARAMSstaticEq.maxIters     = 100;              % Max. number of iterations
PARAMSstaticEq.maxError     = 1.0e-11;          % Max. allowed increment in positions
PARAMSstaticEq.message      = 1;                % Display message with results

% Solve position problem for initial guess
q = positionProb_qFromz(FOURBAR, 1, q_0_guess, PARAMSposProb);

% Solve static equilibrium
q_eq = staticEq(FOURBAR, 1, q, PARAMSposProb, PARAMSstaticEq);

%_______________________________________ Determination of exact eigenvalues
%________________________________________________ (for comparison purposes)

% Equilibrium angle
phi_eq = q_eq(1);

% Linearized terms (analytical expression)
me = 5.0/3.0 * FOURBAR.m * FOURBAR.L^2;
ke =    -2.0 * FOURBAR.m * FOURBAR.L * FOURBAR.g * sin(phi_eq) ...
        -FOURBAR.k * FOURBAR.L^2 * cos(phi_eq)...
        + (FOURBAR.k * FOURBAR.L * FOURBAR.L0) / (sqrt(2.0*(1.0 + cos(phi_eq) ))) ...
        * (cos(phi_eq) + sin(phi_eq)*sin(phi_eq)/(2*(1.0 + cos(phi_eq))));

% Exact eigenvalues 
exact_eig_1 = sqrt(-ke/me);
exact_eig_2 = -sqrt(-ke/me);

%______________________ Linearization with velocity transformation approach
tic
for i=1:1000
%________________________________________ Evaluation of linearization terms

% Evaluate necessary dynamic terms
M           = mass_matrix(FOURBAR.m);
[R, dRdq]   = evalRMtx(FOURBAR, 1, q_eq);
[f, dfdq]   = evalForces(FOURBAR, q_eq);

% Terms for linearization
me_R = R'*M*R;
ke_R = -R'*(dRdq'*f + dfdq*R);

%______________________________________________________________ Eigenvalues
Ar = [0 ke_R; -1 0];
Er = [me_R 0; 0 1];
lambda_eig = eig(-Ar,Er);
end
efficiency = toc;

    fprintf('\n')
str = ['Eigenvalue 1: ' num2str(lambda_eig(1))];
    disp(str)
str = ['Eigenvalue 2: ' num2str(lambda_eig(2))];
    disp(str)

%_______________________________________ Comparison with reference solution
difference = [exact_eig_1-lambda_eig(1);exact_eig_2-lambda_eig(2)];
accuracy = norm(difference,2);

str = ['Accuracy: ' num2str(accuracy)];
    disp(str)
str = ['Efficiency: ' num2str(efficiency) ' s.'];
    disp(str)
