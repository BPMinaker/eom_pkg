function q = get_q_from_phi(FOURBAR, phi)

% Returns the dependent coordinates of the four-bar linkage for a given 
% value of the independent coordinate (angle of rod B-D with respect to the
% global x-axis)
%
% FOURBAR:  system properties
% phi:      independent coordinate
% q:        dependent coordinates
%
% Authors: F. Gonz�lez, P. Masarati, and J. Cuadrado.
% Address all correspondence to f.gonzalez@udc.es

% Retrieve parameters
L       = FOURBAR.L;

% Allocate space
q = zeros(5, 1);

% Angle
q(1) = phi;

% Coordinates of points C and D
q(2) = L * cos(phi);
q(3) = L * sin(phi);
q(4) = q(2) + L;
q(5) = q(3);