function [Phi, Jac, Jacdot, dJacdq, B] = constr_terms(FOURBAR, q, qd)

% Determines the constraints, Jacobian matrix, and their derivatives of the
% four-bar linkage
%
% FOURBAR:  system properties
% q:        generalized coordinates
% qd:       generalized velocities
% Phi:      kinematic constraints
% Jac:      Jacobian matrix of the constraints
% Jacdot:   derivative of the Jacobian w.r.t. time
% dJacdq:   derivative of the Jacobian w.r.t. generalized coordinates
% B:        matrix that relates dependent and independent coordinates
%
% Authors: F. Gonz�lez, P. Masarati, and J. Cuadrado.
% Address all correspondence to f.gonzalez@udc.es

% Retrieve system properties
L       = FOURBAR.L;

% Allocate space
ncstr   = 4;                % Number of kinematic constraints
nvars   = 5;                % Number of variables
Phi     = zeros(ncstr, 1);
Jac     = zeros(ncstr, nvars);
Jacdot  = zeros(ncstr, nvars);
dJacdq  = zeros(ncstr, nvars, nvars);

% Matrix that relates dependent and independent coordinates _______________
B       = zeros(1, nvars);
B(1,1)  = 1.0;              % The angle is the independent coordinate

% Angle constraint ________________________________________________________

% Angle and x, y, coordinates of tip of first rod
phi     = q(1);         phid    = qd(1);
x1      = q(2);         x1d     = qd(2);
y1      = q(3);         y1d     = qd(3);
sphi    = sin(phi);
cphi    = cos(phi);

Phi(1)          = x1 * sphi - y1 * cphi;
Jac(1,1)        = x1 * cphi + y1 * sphi;
Jac(1,2)        =  sphi;
Jac(1,3)        = -cphi;
Jacdot(1,1)     = x1d * cphi - x1 * phid * sphi + ...
                  y1d * sphi + y1 * phid * cphi;
Jacdot(1,2)     =  phid * cphi;
Jacdot(1,3)     = -phid * sphi;
dJacdq(1,1,1)   = -x1 * sphi + q(3) * cphi;
dJacdq(1,2,1)   = cphi;
dJacdq(1,3,1)   = sphi;
dJacdq(1,1,2)   = cphi;
dJacdq(1,1,3)   = sphi;

% Constant distance P0 - P1 _______________________________________________
Phi(2)          = x1^2 + y1^2 - L^2;
Jac(2, 2)       = 2.0 * x1;
Jac(2, 3)       = 2.0 * y1;
Jacdot(2,2)     = 2.0 * x1d;
Jacdot(2,3)     = 2.0 * y1d;
dJacdq(2,2,2)   = 2.0;
dJacdq(2,3,3)   = 2.0;

% Contribution of the other rods in the mechanism _________________________
    
% Retrieve coordinates: 0: C, 1: D
x0  = q(2);         xd0  = qd(2);
y0  = q(3);         yd0  = qd(3);
x1  = q(4);         xd1  = qd(4);
y1  = q(5);         yd1  = qd(5);
    
% Array of constraints
Phi(3) = (x1-x0)^2  + (y1-y0)^2 - L^2;      % Horizontal rod
Phi(4) = (x1-L)^2 + y1^2 - L^2;             % Vertical rod
    
% Jacobian matrix
Jac(3, 2)   = -2.0 * (x1-x0);
Jac(3, 3)   = -2.0 * (y1-y0);
Jac(3, 4)   =  2.0 * (x1-x0);
Jac(3, 5)   =  2.0 * (y1-y0);
    
Jac(4, 4)   =  2.0 * (x1-L);
Jac(4, 5)   =  2.0 * y1;

% Time derivative of Jacobian matrix
Jacdot(3, 2)    = -2.0 * (xd1-xd0);
Jacdot(3, 3)    = -2.0 * (yd1-yd0);
Jacdot(3, 4)    =  2.0 * (xd1-xd0);
Jacdot(3, 5)    =  2.0 * (yd1-yd0);

Jacdot(4, 4)    =  2.0 * xd1;
Jacdot(4, 5)    =  2.0 * yd1;

% Partial derivative of Jacobian matrix with respect to coordinates
dJacdq(3, 2, 2) =   2.0;
dJacdq(3, 2, 4) =  -2.0;
dJacdq(3, 3, 3) =   2.0;
dJacdq(3, 3, 5) =  -2.0;
dJacdq(3, 4, 2) =  -2.0;
dJacdq(3, 4, 4) =   2.0;
dJacdq(3, 5, 3) =  -2.0;
dJacdq(3, 5, 5) =   2.0;

dJacdq(4, 4, 4) =  2.0;
dJacdq(4, 5, 5) =  2.0;