function qd = velocityProb_qFromz(FOURBAR, zidx, zvel, q)

% Solve the velocity problem of the linkage for a given velocity of the
% degrees of freedom.
%
% The method used is a least-squares penalty approach.
%
% FOURBAR:  system properties
% zidx:     index of independent coordinate in array q
% zvel:     velocity of the degrees of freedom
% q:       	generalized coordinates of the linkage
% qd:       velocities of the linkage
%
% Authors: F. Gonz�lez, P. Masarati, and J. Cuadrado.
% Address all correspondence to f.gonzalez@udc.es

% Penalty term
alpha = 1.0e15;

% Obtain Jacobian matrix and constraints vector
[~, Jac, ~, ~, ~] = constr_terms(FOURBAR, q, zeros(length(q)));
ATA         = (Jac')*Jac;

% Fill rhs
rhs = zeros(size(ATA,1), 1);

% Make sure that velocity of degrees of freedom does not change
rhs(zidx)       = zvel*alpha;
ATA(zidx,zidx)  = alpha;

% Solve
qd = ATA\rhs;