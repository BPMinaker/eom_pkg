function [f, dFdq] = evalForces(FOURBAR, q)

% Function that returns the generalized forces that act on the four-bar
% linkage
%
% FOURBAR:  system properties
% q:        generalized coordinates
% f:        generalized forces
% dFdq:     stiffness matrix
%
% Authors: F. Gonz�lez, P. Masarati, and J. Cuadrado.
% Address all correspondence to f.gonzalez@udc.es

% Allocate memory
f       = zeros(length(q),1);
dFdq    = zeros(length(q),length(q));

% Retrieve values
g       = FOURBAR.g;
m       = FOURBAR.m;
L       = FOURBAR.L;
k       = FOURBAR.k;
L0      = FOURBAR.L0;

% Gravitational actions ___________________________________________________

% Vertical rod A-C
f(3) = -m*g/2.0;

% Horizontal rod
f(3) = f(3) - m*g/2.0;
f(5) = f(5) - m*g/2.0;
    
% Vertical rod B-D
f(5) = f(5) - m*g/2.0;


% Forces from the spring __________________________________________________
    
% Coordinates of upper right corner in the loop
xD = q(4);
yD = q(5);    
Lk          = sqrt( xD^2 + yD^2);
stiffCoeff  = -k * (Lk - L0) / Lk;

% Contribution to forces vector
f(4) = f (4) + stiffCoeff * xD;
f(5) = f (5) + stiffCoeff * yD;
    
% Contribution to stiffness matrix
dFdq(4,4) = k*(L0*(Lk^2-xD^2)/Lk^3 - 1.0);
dFdq(4,5) = -k * xD*yD * L0 / Lk^3;
dFdq(5,4) = dFdq(4,5);
dFdq(5,5) = k*(L0*(Lk^2-yD^2)/Lk^3 - 1.0);
