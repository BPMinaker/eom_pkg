function A = hypergemv (MM, b)

% Performs the hyperproduct MM * b = v
% MM:   hypermatrix, m x n x p
% b:    vector, n x 1
% A:    matrix, m x p
%
% Authors: F. Gonz�lez, P. Masarati, and J. Cuadrado.
% Address all correspondence to f.gonzalez@udc.es

A = zeros( size(MM,1), size(MM,3) );

for i=1:size(MM, 3)
    A(:,i) = MM(:,:,i) * b;
end